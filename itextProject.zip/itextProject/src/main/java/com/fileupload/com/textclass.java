/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.fileupload.com;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfSignatureAppearance;
import com.mycompany.itextproject.multipleAppearance;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;

/**
 *
 * @author sudhanvastilgul
 */

@WebServlet(name = "textclass", urlPatterns = {"/textclass"})
public class textclass extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException  {
    JSONObject json = new JSONObject();

    System.out.println("json "+request.getParameter("username"));

json.put("name",request.getParameter("username"));
json.put("reason",request.getParameter("rsn"));
System.out.println("json "+json.toString());
        multipleAppearance multi = new multipleAppearance();
        try {
            multi.multipleAppearance(request,json);
//        PdfSignatureAppearance appear = multi.sign("name");
//        multi.signature(appear);

        
        } catch (DocumentException ex) {
            Logger.getLogger(textclass.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(textclass.class.getName()).log(Level.SEVERE, null, ex);
        }
          getServletContext().getRequestDispatcher("/Done.jsp").forward(
                    request, response);
    }
    
    
}
