/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.fileupload.com;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoDatabase;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import static jdk.nashorn.internal.objects.NativeError.getStackTrace;

/**
 *
 * @author rashmihc
 */
public class MongoConnection {
    // private static MongoConnection instance = new MongoConnection();
    static MongoClientURI uri;
    static MongoClient mongoClient;
    static MongoDatabase database;
    

    static  {
        // MongoClientOptions.Builder options = MongoClientOptions.builder();
        // options.socketKeepAlive(true);
        // mongoClient = new MongoClient(commonCode.MONGO_CONNECTION_STRING, options.build());
        try{
        uri = new MongoClientURI(commonCode.MONGO_CONNECTION_STRING);
        mongoClient = new MongoClient(uri);
        database = mongoClient.getDatabase(commonCode.MONGO_DB_NAME);
        }catch(Exception exception){
            exception.printStackTrace();
            // SendErrorReportEmail(getStackTrace(exception));
        }
        System.out.println("Initial db instance created");
       // SendErrorReportEmail("Initial db instance created");
    }

    private MongoConnection() {
    }

    public static MongoDatabase getMongoInstance() throws RuntimeException {

        if (database == null) {           
            try {
                uri = new MongoClientURI(commonCode.MONGO_CONNECTION_STRING);
                mongoClient = new MongoClient(uri);
                database = mongoClient.getDatabase(commonCode.MONGO_DB_NAME);
                 System.out.println("new db instance created");
            // SendMail("new db instance created:");
               // SendErrorReportEmail("new db instance created");
            } catch (Exception exception) {
                exception.printStackTrace();
               // SendErrorReportEmail(getStackTrace(exception));

            }
            return database;
        } else {

            //SendMail("sending email");
            return database;
        }
    }




