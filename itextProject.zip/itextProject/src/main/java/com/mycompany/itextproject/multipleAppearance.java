/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.itextproject;

import com.fileupload.com.MongoConnection;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfAnnotation;
import com.itextpdf.text.pdf.PdfDate;
import com.itextpdf.text.pdf.PdfDictionary;
import com.itextpdf.text.pdf.PdfFormField;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfSignature;
import com.itextpdf.text.pdf.PdfSignatureAppearance;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfString;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.codec.Base64;
import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import com.mongodb.util.JSON;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.json.Json;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.CMSSignedData;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;
import org.json.JSONObject;
import sun.security.pkcs.PKCS7;

/**
 *
 * @author sudhanvastilgul
 */

//@WebServlet(name = "multipleAppearance", urlPatterns = {"/multipleAppearance"})
public class multipleAppearance  {
    
   private String name = "";
   private String reason = "";
    public void multipleAppearance(JSONObject json) throws DocumentException, IOException{
        
          MongoDatabase database = MongoConnection.getMongoInstance();
            org.bson.Document sd_dev = database.getCollection("sd_dev").find().first();
            System.out.println("json in multi "+json.toString());
            MongoCollection<Document> gradesCollection = database.getCollection("sd_dev");
            
     org.bson.Document  student = new Document("_id", new ObjectId());
        
        
                student.append("input_file_path", json.getString("input_file_path"))
                .append("output_file_path", json.getString("output_file_path"));
               gradesCollection.insertOne(student);
        
               JSONObject json1 = new JSONObject();
               student.toJson();
       student.get("_id");
          
    }
    
    public void multipleAppearance(HttpServletRequest request,JSONObject json) throws DocumentException, IOException{
         
        MongoDatabase database = MongoConnection.getMongoInstance();
        name = request.getParameter("username");
         reason = request.getParameter("rsn");
         json.put("name", name);
         json.put("reason", reason);
         //get latest _id
         MongoCollection<Document> collection = database.getCollection("sd_dev");
         Document mydoc1 = collection.find().sort(new Document("_id", -1)).first();
         JSONObject json11 = new JSONObject(mydoc1);
         System.out.println("json 11 "+json11);
         org.bson.Document myDoc = collection.find().sort(new Document("_id", -1)).first();
         
         JSONObject json1 = new JSONObject(myDoc);
         System.out.println("json1 "+json1);
         JSONObject idObj = (JSONObject)json1.get("_id");
         System.out.println("idObj "+idObj);
        String strID = "";
        System.out.println("signer "+strID);\
         
         Bson query = collection.find().sort(new Document("_id", -1)).first();
         BasicDBObject update = new BasicDBObject();
update.put("$set", new BasicDBObject("signername", json.getString("name")));\
         
database.getCollection("sd_dev").updateOne(query, update);

org.bson.Document myDoc3 = collection.find().sort(new Document("_id", -1)).first();
json1 = new JSONObject(myDoc3);
        System.out.println("json " +json1.toString());


         multipleAppearance multi = new multipleAppearance();
         HashMap m = new HashMap();
                
         m = multi.sign(json1);
        multi.signature(m);
    }


    public HashMap sign(JSONObject signerid) throws DocumentException, IOException {
        FileOutputStream fileoutstream = null;
        Map<String, Object> response = new HashMap<String, Object>();
        JSONObject sdDev = signerid;
        
System.out.println("sd "+sdDev);

        Rectangle rectangle = new Rectangle(10, 10, 120, 60);
        String currentDesination = sdDev.getString("output_file_path");
        
        String InputFilePath = sdDev.getString("input_file_path");
        JSONObject json = new JSONObject();
        json.put("input_file_path", InputFilePath);
        json.put("output_file_path",currentDesination);
        fileoutstream = new FileOutputStream(currentDesination);
        PdfReader reader = new PdfReader(InputFilePath);
        ArrayList<PdfSignatureAppearance> pdfSignatureAppearances = new ArrayList();
        pdfSignatureAppearances = new ArrayList();

        ByteArrayOutputStream out = new ByteArrayOutputStream();

        PdfStamper stamper1 = new PdfStamper(reader, out, '\003', true);

        PdfFormField sig = PdfFormField.createSignature(stamper1.getWriter());

        SimpleDateFormat sd1 = new SimpleDateFormat("dd MMM yyyy 'at' HH:mm:ss z");

        String SignFeildName = "Hello";
        Date date1 = new Date();
        sd1.setTimeZone(TimeZone.getTimeZone("IST"));
        String appearanceDate = sd1.format(date1);

        sig.setWidget(rectangle, null);
        sig.setFlags(4);
        sig.put(PdfName.DA, new PdfString("/Helv 0 Tf 0 g"));
        sig.setFieldFlags(PdfAnnotation.FLAGS_PRINT);
        sig.setFieldName(SignFeildName);
        stamper1.addAnnotation(sig, 1);

        stamper1.close();
        out.close();
        if (reader != null) {
            reader.close();
        }


        reader = new PdfReader(out.toByteArray());

        PdfStamper stamper2 = PdfStamper.createSignature(reader, fileoutstream, '\000', null, true);

        PdfSignatureAppearance appearance = stamper2.getSignatureAppearance();

        Calendar cal = Calendar.getInstance();
        cal.add(12, 10);
        appearance.setSignDate(cal);
        boolean esign2 = true;
        appearance.setVisibleSignature(SignFeildName);
        appearance.setCertificationLevel(0);
        Date date = cal.getTime();
        sd1.setTimeZone(TimeZone.getTimeZone("IST"));
        String dateString = sd1.format(date);
        String Reason = "esign";
        String signerName = sdDev.getString("signername");

        if (esign2) {
            String IMG = "";//path of the background image to be used
            String FONT_VELO = "";//path of the font to be used
            String FONT_SANS = "";//path of the font to be used
            Font f1 = FontFactory.getFont(FONT_SANS, BaseFont.IDENTITY_H, BaseFont.EMBEDDED, 13.5f, Font.NORMAL, new BaseColor(0, 0, 0)); // new Font(FontFamily.TIMES_ROMAN, 9.5f, Font.BOLDITALIC, new BaseColor(56, 84, 38));
            Font f2 = FontFactory.getFont(FONT_SANS, BaseFont.IDENTITY_H, BaseFont.EMBEDDED, 6f, Font.NORMAL, new BaseColor(102, 102, 102)); // new Font(FontFamily.TIMES_ROMAN, 7.5f, Font.NORMAL, new BaseColor(75, 75, 75));
            Font f3 = FontFactory.getFont(FONT_SANS, BaseFont.IDENTITY_H, BaseFont.EMBEDDED, 4f, Font.NORMAL, new BaseColor(0, 0, 0));
            Font f4 = FontFactory.getFont(FONT_SANS, BaseFont.IDENTITY_H, BaseFont.EMBEDDED, 4f, Font.NORMAL, new BaseColor(102, 102, 102));
            Font f5 = FontFactory.getFont(FONT_SANS, BaseFont.IDENTITY_H, BaseFont.EMBEDDED, 5f, Font.NORMAL, new BaseColor(0, 0, 0));
            Font underline = FontFactory.getFont(FONT_SANS, BaseFont.IDENTITY_H, BaseFont.EMBEDDED, 4f, Font.UNDERLINE, new BaseColor(0, 0, 0));
            Font remarksFont = FontFactory.getFont(FONT_SANS, BaseFont.IDENTITY_H, BaseFont.EMBEDDED, 4f, Font.NORMAL, new BaseColor(102, 102, 102));

            float w = rectangle.getWidth();
            float h = rectangle.getHeight();
            float x = (rectangle.getLeft() + rectangle.getRight()) / 2;
            float y = (rectangle.getTop() + rectangle.getBottom()) / 2;

            PdfTemplate n2 = appearance.getLayer(2);

            Phrase p1 = new Phrase();

            if (!(signerName.equals("")) && !(signerName == null)) {
                signerName = signerName.trim();
                String words[] = signerName.split("\\s+");
                String capitalizeWord = "";
                for (String wrd : words) {
                    String first = wrd.substring(0, 1);
                    String afterfirst = wrd.substring(1);
                    capitalizeWord += first.toUpperCase() + afterfirst + " ";
                }
                signerName = capitalizeWord.trim();
            }

            p1 = new Phrase(signerName, f1);

            Phrase p2, p4, p6 = new Phrase();
            Phrase p3 = new Phrase();
            Phrase p5 = new Phrase();

            if (!Reason.equals("") && !Reason.equals("NA")) {

                p6 = new Phrase("Something" + ": " + Reason, remarksFont);
//p6 = new Phrase("Designation: " + Reason, remarksFont);
            }
            Chunk c = new Chunk(appearanceDate + " (UTC+05:30)", underline);
            StringBuilder sb = new StringBuilder(13);
            for (int i = 0; i < 13; i++) {
                c.append("\u00a0");
            }
            p3.add(c);
            p4 = new Phrase("digital", f3);
            p5.add(new Chunk("eSign", f5));

            p2 = new Phrase("", f2);
            Image img = Image.getInstance(IMG);

//            image.add(new Chunk(img, 0, 0, true));
            Rectangle dataRect = new Rectangle(
                    0,
                    0,
                    rectangle.getWidth(),
                    rectangle.getHeight());

            Rectangle dataRect1 = new Rectangle(
                    1,
                    0,
                    rectangle.getWidth() + rectangle.getWidth() / 4,
                    rectangle.getHeight() / 2);
            Rectangle imgRect = new Rectangle(
                    0,
                    0,
                    rectangle.getWidth(),
                    rectangle.getHeight());
            img.scaleAbsolute(rectangle);
            Phrase image = new Phrase(new Chunk(img, 0, 0, true));
            float heightChanges = 7f;

            float signedSize = ColumnText.fitText(new Font(), SignFeildName, rectangle, -1, PdfWriter.RUN_DIRECTION_NO_BIDI);
            if (signedSize < 18f) {
                heightChanges = 10f;
            }
            ColumnText ctImg = new ColumnText(n2);
            ctImg.setSimpleColumn(image, imgRect.getLeft(), imgRect.getBottom(), imgRect.getRight(), imgRect.getTop(), 1, Element.ALIGN_RIGHT);
            ctImg.setText(image);
            ctImg.go();
            float maxF1Size = getMaxFontSize(f1.getBaseFont(), signerName, w / 1.2f, h / 2.2f);
            f1.setSize(maxF1Size);

            ColumnText ct = new ColumnText(n2);
            ct.setRunDirection(appearance.getRunDirection());
            ct.setSimpleColumn(p1, dataRect.getLeft(), dataRect.getBottom(), dataRect.getRight(), dataRect.getTop() - (dataRect.getHeight() / heightChanges), f1.getSize(), Element.ALIGN_LEFT);
            ct.go();
//                } else {
//                ColumnText.showTextAligned(n2, Element.ALIGN_LEFT , p1, rectangle.getLeft(), y + (h / 10f)+2, 0);
//                }
            float maxF2Size2 = getMaxFontSize(f2.getBaseFont(), signerName, w / 2.5f, h / 6);
            float maxF4Size2 = getMaxFontSize(f3.getBaseFont(), "Aadhaar", w / 5.5f, h / 2);
            float maxF5Size = getMaxFontSize(f5.getBaseFont(), "", w / 5.5f, h / 2);
            f2.setSize(maxF2Size2);
            f3.setSize(maxF4Size2);
            f5.setSize(maxF5Size);
            float maxFontSizeRemarks = 0f;

            if (!Reason.equals("") && !Reason.equals("NA")) {
                maxFontSizeRemarks = getMaxFontSize(remarksFont.getBaseFont(), "something" + ": " + Reason + "    ", w / 2.5f, h / 2f);
                remarksFont.setSize(maxFontSizeRemarks);
            }

            float maxFontSize3 = getMaxFontSize(underline.getBaseFont(), dateString + " (UTC+05:30)", w / 1.5f, h / 2);
            underline.setSize(maxFontSize3);
            if (!Reason.equals("") && !Reason.equals("NA")) {
                ColumnText ct2 = new ColumnText(n2);
                ct2.setSimpleColumn(p3, dataRect.getLeft(), dataRect.getBottom(), dataRect.getRight() - 4, dataRect.getTop() - (dataRect.getHeight() / 1.40f), underline.getSize(), Element.ALIGN_LEFT);
                ct2.go();
                ColumnText ct3 = new ColumnText(n2);

                ct3.setSimpleColumn(p4, dataRect.getLeft(), dataRect.getBottom(), dataRect.getRight(), dataRect.getTop() - (dataRect.getHeight() / 1.7f), f3.getSize(), Element.ALIGN_RIGHT);

                ct3.go();
                ColumnText ct4 = new ColumnText(n2);
                ct4.setSimpleColumn(p5, dataRect.getLeft(), dataRect.getBottom(), dataRect.getRight() - 5, dataRect.getTop() - (dataRect.getHeight() / 1.35f), f4.getSize(), Element.ALIGN_RIGHT);
                ct4.go();
                ColumnText ct5 = new ColumnText(n2);
                if (maxFontSizeRemarks > 8) {
                    ct5.setSimpleColumn(p6, dataRect.getLeft(), dataRect.getBottom(), dataRect.getRight(), dataRect.getTop() - (dataRect.getHeight() / 1.32f), remarksFont.getSize(), Element.ALIGN_LEFT);
                } else if (maxFontSizeRemarks > 5) {
                    ct5.setSimpleColumn(p6, dataRect.getLeft(), dataRect.getBottom(), dataRect.getRight(), dataRect.getTop() - (dataRect.getHeight() / 1.25f), remarksFont.getSize(), Element.ALIGN_LEFT);
                } else {
                    ct5.setSimpleColumn(p6, dataRect.getLeft(), dataRect.getBottom(), dataRect.getRight(), dataRect.getTop() - (dataRect.getHeight() / 1.15f), remarksFont.getSize(), Element.ALIGN_LEFT);
                }
                ct5.go();
            } else {
                ColumnText ct2 = new ColumnText(n2);
                ct2.setSimpleColumn(p3, dataRect.getLeft(), dataRect.getBottom(), dataRect.getRight() - dataRect.getWidth() / 5f, dataRect.getTop() - dataRect.getHeight() / 1.3f, underline.getSize(), Element.ALIGN_LEFT);
                ct2.go();
                ColumnText ct3 = new ColumnText(n2);

                ct3.setSimpleColumn(p4, dataRect.getLeft(), dataRect.getBottom(), dataRect.getRight(), dataRect.getTop() - dataRect.getHeight() / 1.4f, f4.getSize(), Element.ALIGN_RIGHT);

                ct3.go();
                ColumnText ct4 = new ColumnText(n2);
                ct4.setSimpleColumn(p5, dataRect.getLeft(), dataRect.getBottom(), dataRect.getRight() - 5, dataRect.getTop() - dataRect.getHeight() / 1.2f, f5.getSize(), Element.ALIGN_RIGHT);
                ct4.go();
            }
        }
        String appearanaceTextL1 = "Digitally Signed Document\n";
        String appearanaceTextL3 = "\nSigned ";

        signerName = "Something";
        if (!(signerName.equals("")) && !(signerName == null)) {
            signerName = signerName.trim();
            String words[] = signerName.split("\\s+");
            String capitalizeWord = "";
            for (String w : words) {
                String first = w.substring(0, 1);
                String afterfirst = w.substring(1);
                capitalizeWord += first.toUpperCase() + afterfirst + " ";
            }

            signerName = capitalizeWord.trim();
            appearanaceTextL1 = "Digitally Signed by " + signerName + "\n";
        }
        String Appearanace_text = appearanaceTextL1 + appearanceDate + appearanaceTextL3;//"\nSigned using SignDesk" + ReasonLine

        appearance.setLayer2Text(Appearanace_text);

        PdfSignature dic = new PdfSignature(PdfName.ADOBE_PPKLITE, PdfName.ADBE_PKCS7_DETACHED);
        dic.setDate(new PdfDate(appearance.getSignDate()));

        appearance.setCryptoDictionary(dic);
        HashMap<PdfName, Integer> exc = new HashMap();
        exc.put(PdfName.CONTENTS, new Integer(16579 * 2 + 2));
        appearance.preClose(exc);
        
        response.put("appearance", appearance);
        response.put("json",json);
        return (HashMap) response;
    }

    public void signature(HashMap map) throws DocumentException, IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
       JSONObject json1 = (JSONObject) map.get("json");
       System.out.println("json1 "+json1.toString());
        PdfStamper stamper2 = null;
        //String folderPath = "/home/sudhanvastilgul/Downloads";
        String currentDesination = json1.getString("output_file_path");
        String InputFilePath = json1.getString("input_file_path");
        PdfReader reader = new PdfReader(InputFilePath);
        FileOutputStream os = new FileOutputStream(currentDesination);

        stamper2 = new PdfStamper(reader, out, '\003', true);

        PdfSignatureAppearance appearance = (PdfSignatureAppearance) map.get("appearance");//(PdfSignatureAppearance) session.getAttribute("appearanceobject");

        if (appearance != null) {

            String bytes = "17876";
            byte[] pk1 = bytes.getBytes();
            System.out.println("pk1 length---" + pk1.length);
            byte[] outc = new byte[16579];
            PdfDictionary dic2 = new PdfDictionary();
            System.arraycopy(pk1, 0, outc, 0, pk1.length);
            dic2.put(PdfName.CONTENTS, new PdfString(outc).setHexWriting(true));
            appearance.close(dic2);
            stamper2.close();
            reader.close();
            os.close();
            out.close();
        }
      
    }

    private static float getMaxFontSize(BaseFont bf, String text, float width, float height) {
        // avoid infinite loop when text is empty

        float fontSize = 0.1f;
        while (bf.getWidthPoint(text, fontSize) < width) {
            fontSize += 0.1f;
        }

        float maxHeight = measureHeight(bf, text, fontSize);
        while (maxHeight > height) {
            fontSize -= 0.1f;
            maxHeight = measureHeight(bf, text, fontSize);
        };

        return fontSize;
    }

    public static float measureHeight(BaseFont baseFont, String text, float fontSize) {
        float ascend = baseFont.getAscentPoint(text, fontSize);
        float descend = baseFont.getDescentPoint(text, fontSize);
        return ascend - descend;
    }

    public static void main(String[] args) throws DocumentException, IOException {
//        multipleAppearance multi = new multipleAppearance();
//        PdfSignatureAppearance appear = multi.sign();
//        multi.signature(appear);
    }
}
